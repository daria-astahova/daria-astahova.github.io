﻿

var AppInfo = {
    //	Wss: true,
        AppId: "daa34a39-f0cb-4210-bebb-65facd69140b",
        AppVersion: "1.0",
        Region: "usw", // <-- Add this line
    //  MasterServer: "localhost:9090",
    //  NameServer: "ws://localhost:9093",
    //  FbAppId: "you fb app id", 
    }